// Chat JS
console.log('Chat initialized');